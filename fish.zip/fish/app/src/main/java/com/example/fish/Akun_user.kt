package com.example.fish

import android.content.Intent
import android.content.SharedPreferences
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class Akun_user : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.akun_user)
        val txt_nama_user:TextView=findViewById(R.id.txt_nama_user)
        val txt_email_admin:TextView=findViewById(R.id.txt_email_user)
        val txt_password:TextView=findViewById(R.id.txt_password_user)
        val txt_logout:TextView=findViewById(R.id.txt_logout)
        val txt_kembali:TextView=findViewById(R.id.txt_kembali)
        val db:SQLiteDatabase = openOrCreateDatabase("toeifish", MODE_PRIVATE, null)
        val tiket:SharedPreferences=getSharedPreferences("user", MODE_PRIVATE)
        val email_user:String?=tiket.getString("email_user",null)
        val password:String?=tiket.getString("password",null)
        val cursor: Cursor = db.rawQuery("SELECT nama_user FROM user WHERE email_user = ? AND password = ?", arrayOf(email_user, password))
        if (cursor.moveToFirst()) {
            val namauserIndex: Int = cursor.getColumnIndex("nama_user")
            val namauser: String = cursor.getString(namauserIndex)

            txt_nama_user.text = "$namauser"
        }


        txt_email_admin.text="Email : "+email_user
        txt_password.text="Password : "+password
        txt_logout.setOnClickListener {
            val edit_tiket = tiket.edit()
            edit_tiket.clear()
            edit_tiket.commit()
            val keluar:Intent=Intent(this,Login::class.java)
            startActivity(keluar)
        }
        txt_kembali.setOnClickListener {
            val kembali:Intent=Intent(this,Dashboard_user::class.java)
            startActivity(kembali)
        }





    }
}