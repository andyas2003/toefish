package com.example.fish

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        val edt_email: EditText = findViewById(R.id.edt_email)
        val edt_password: EditText = findViewById(R.id.edt_password)
        val btn_login: Button = findViewById(R.id.btn_login)
        val daftar:TextView=findViewById(R.id.txt_daftar)
        daftar.setOnClickListener {
            val daftar:Intent=Intent(this,Daftar::class.java)
            startActivity(daftar)
        }

        btn_login.setOnClickListener {
            val isi_email: String = edt_email.text.toString()
            val isi_password: String = edt_password.text.toString()
            val db: SQLiteDatabase = openOrCreateDatabase("toeifish", MODE_PRIVATE, null)
            val queryuser = db.rawQuery("SELECT * FROM user WHERE email_user='$isi_email' AND password='$isi_password'", null)
            val cekuser = queryuser.moveToNext()
            if (cekuser) {
                val id_pelogin = queryuser.getString(0)
                val email_pelogin = queryuser.getString(2)
                val password = queryuser.getString(3)
                val session: SharedPreferences = getSharedPreferences("user", MODE_PRIVATE)
                val buattiket = session.edit()
                buattiket.putString("id_user", id_pelogin)
                buattiket.putString("email_user", email_pelogin)
                buattiket.putString("password", password)
                buattiket.apply()
                val pindah: Intent = Intent(this, Dashboard_user::class.java)
                startActivity(pindah)
            } else {
                val queryadmin = db.rawQuery("SELECT * FROM admin WHERE email_admin='$isi_email' AND password='$isi_password'", null)
                val cekadmin = queryadmin.moveToNext()
                if (cekadmin) {
                    val id_admin = queryadmin.getString(0)
                    val email_admin = queryadmin.getString(1)
                    val password = queryadmin.getString(2)
                    val session: SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
                    val buattiket = session.edit()
                    buattiket.putString("id_admin", id_admin)
                    buattiket.putString("email_admin", email_admin)
                    buattiket.putString("password", password)
                    buattiket.apply()
                    val pindahadmin: Intent = Intent(this, Dashboard::class.java)
                    startActivity(pindahadmin)
                } else {
                     Toast.makeText(this, "Email atau Password salah !!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}