package com.example.fish

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Produk : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk)
        val rv_produk:RecyclerView =findViewById(R.id.rv_produk)
        val id_produk:MutableList<String> = mutableListOf()
        val nama_produk: MutableList<String> = mutableListOf()
        val harga_produk: MutableList<String> = mutableListOf()
        val foto_produk: MutableList<Bitmap> = mutableListOf()
        val db :SQLiteDatabase = openOrCreateDatabase("toeifish", MODE_PRIVATE, null)
        val gali_produk = db.rawQuery("SELECT * FROM produk", null)
        while (gali_produk.moveToNext())
        {
            try {
                val bis = ByteArrayInputStream(gali_produk.getBlob(3))
                val gambarbitmap:Bitmap=BitmapFactory.decodeStream(bis)
                foto_produk.add(gambarbitmap)

            }catch (e:Exception){
                val gambarbitmap= BitmapFactory.decodeResource(this.resources,R.drawable.image_upload)
                foto_produk.add(gambarbitmap)
            }
            id_produk.add(gali_produk.getString(0))
            nama_produk.add(gali_produk.getString(1))
            harga_produk.add("Harga = "+gali_produk.getString(2))

        }

        val adapter = Produk_item(this,id_produk, nama_produk, harga_produk, foto_produk)
        rv_produk.adapter = adapter
        rv_produk.layoutManager = GridLayoutManager(this, 1)

        val btn_tambah: Button = findViewById(R.id.btn_tambah)
        val btn_kembali:Button = findViewById(R.id.btn_kembali)
        btn_tambah.setOnClickListener {
            val pindah: Intent = Intent(this, Produk_tambah::class.java)
            startActivity(pindah)
        }
        btn_kembali.setOnClickListener {
            val kembali:Intent=Intent(this,Dashboard::class.java)
            startActivity(kembali)
        }



    }
}