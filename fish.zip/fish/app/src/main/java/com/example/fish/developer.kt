package com.example.fish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class developer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.developer)
        val txt_kembali: TextView =findViewById(R.id.txt_kembali)
        txt_kembali.setOnClickListener {
            val kembali: Intent = Intent(this,Dashboard::class.java)
            startActivity(kembali)
        }
    }
}