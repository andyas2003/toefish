package com.example.fish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)
        val iv_akun: ImageView = findViewById(R.id.iv_akun)
        val iv_produk : ImageView = findViewById(R.id.iv_produk)
        val iv_info :ImageView=findViewById(R.id.iv_info)
        val iv_developer :ImageView=findViewById(R.id.iv_developer)
        iv_info.setOnClickListener {
            val pindahinfo:Intent=Intent(this,Info_aplikasi::class.java)
            startActivity(pindahinfo)
        }
        iv_akun.setOnClickListener {
            val pindahakun = Intent(this, Akun::class.java)
            startActivity(pindahakun)
        }
        iv_produk.setOnClickListener {
            val pindahproduk = Intent(this, Produk::class.java)
            startActivity(pindahproduk)
        }
        iv_developer.setOnClickListener {
            val pindahdeveloper = Intent(this, developer::class.java)
            startActivity(pindahdeveloper)
        }
    }
}