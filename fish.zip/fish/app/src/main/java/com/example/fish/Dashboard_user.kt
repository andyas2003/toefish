package com.example.fish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class Dashboard_user : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard_user)
        val iv_akun: ImageView = findViewById(R.id.iv_akun)
        val iv_produk : ImageView = findViewById(R.id.iv_produk)
        val iv_info :ImageView=findViewById(R.id.iv_info)
        val iv_developer :ImageView=findViewById(R.id.iv_developer)
        iv_info.setOnClickListener {
            val pindahinfo:Intent=Intent(this,Infoapkforuser::class.java)
            startActivity(pindahinfo)
        }
        iv_akun.setOnClickListener {
            val pindahakun = Intent(this, Akun_user::class.java)
            startActivity(pindahakun)
        }
        iv_produk.setOnClickListener {
            val pindahproduk = Intent(this, Produk_user::class.java)
            startActivity(pindahproduk)
        }
        iv_developer.setOnClickListener {
            val pindahdeveloper = Intent(this, Developerforuser::class.java)
            startActivity(pindahdeveloper)
        }
    }
}