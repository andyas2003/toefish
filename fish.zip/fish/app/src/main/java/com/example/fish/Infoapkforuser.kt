package com.example.fish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Infoapkforuser : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.infoapkforuser)
        val btn_kembali :Button=findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val kembali:Intent=Intent(this,Dashboard_user::class.java)
            startActivity(kembali)
        }
    }
}