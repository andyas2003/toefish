package com.example.fish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class berhasil_daftar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.berhasil_daftar)
        val btn_login:Button=findViewById(R.id.btn_login)
        btn_login.setOnClickListener {
            val login:Intent=Intent(this,Login::class.java)
            startActivity(login)
        }
    }
}