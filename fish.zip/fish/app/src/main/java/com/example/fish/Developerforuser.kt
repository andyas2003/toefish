package com.example.fish

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Developerforuser : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.developerforuser)
        val txt_kembali: TextView =findViewById(R.id.txt_kembali)
        txt_kembali.setOnClickListener {
            val kembali: Intent = Intent(this,Dashboard_user::class.java)
            startActivity(kembali)
        }
    }
}