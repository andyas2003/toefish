package com.example.fish

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Dialog : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog)
    }
}