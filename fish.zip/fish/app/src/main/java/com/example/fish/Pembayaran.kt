package com.example.fish
import android.app.AlertDialog


import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Pembayaran : AppCompatActivity() {
    private fun showDialog() {
        val dialogBuilder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.dialog, null)

        dialogBuilder.setView(view)
        val alertDialog = dialogBuilder.create()

        alertDialog.window?.setBackgroundDrawableResource(R.drawable.color_kosong)

        val buttonYes = view.findViewById<Button>(R.id.btn_ya)
        val buttonNo = view.findViewById<Button>(R.id.btn_tidak)

        buttonYes.setOnClickListener {
            val beli = Intent(this, Pembayaran_sukses::class.java)
            startActivity(beli)
            alertDialog.dismiss()
        }

        buttonNo.setOnClickListener {
            alertDialog.dismiss()
        }

        alertDialog.show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pembayaran)
        val txt_nama_produk:TextView=findViewById(R.id.txt_produk)
        val txt_harga_produk:TextView=findViewById(R.id.txt_harga_produk)
        val nama_produk: String? = intent.getStringExtra("nama_produk")
        val harga_produk: String? = intent.getStringExtra("harga_produk")
        if (nama_produk != null && harga_produk != null) {

            txt_nama_produk.text = nama_produk
            txt_harga_produk.text = harga_produk
        }
        val hargaProduk: Int = harga_produk?.toIntOrNull() ?: 0
        val seekbar : SeekBar=findViewById(R.id.sb_jumlah)
        val txt_jumlahproduk:TextView=findViewById(R.id.txt_jumlahproduk)
        val txtTotalHarga: TextView = findViewById(R.id.txt_total_harga)
        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val jumlahproduk = progress + 1
                val subtotal = jumlahproduk * hargaProduk

                txt_jumlahproduk.text = "$jumlahproduk"
                txtTotalHarga.text = "$subtotal"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val btn_beli:Button=findViewById(R.id.btn_beli)
        btn_beli.setOnClickListener {
            showDialog()


        }


        val btn_kembali:Button=findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah:Intent=Intent(this,Produk_user::class.java)
            startActivity(pindah)
        }


    }

}