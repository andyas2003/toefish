package com.example.fish

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class Daftar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.daftar)
        val edt_fullnama : EditText=findViewById(R.id.edt_namalenhkap)
        val edt_fullemail : EditText=findViewById(R.id.edt_emaildaftar)
        val edt_fullpass : EditText=findViewById(R.id.edt_passworddaftar)
        val btn_daftar:Button=findViewById(R.id.btn_daftar)
        btn_daftar.setOnClickListener {
            val inputnama:String=edt_fullnama.text.toString()
            val inputemail:String=edt_fullemail.text.toString()
            val inputpass:String=edt_fullpass.text.toString()
            val db: SQLiteDatabase = openOrCreateDatabase("toeifish", MODE_PRIVATE,null)
            val sql = "INSERT INTO user (nama_user,email_user,password) VALUES(?,?,?)"
            val statement = db.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, inputnama)
            statement.bindString(2, inputemail)
            statement.bindString(3, inputpass)
            statement.executeInsert()
            val pindah:Intent = Intent(this, berhasil_daftar::class.java)
            startActivity(pindah)
        }

        val masuk:TextView=findViewById(R.id.txt_masuk)
        masuk.setOnClickListener {
            val masuk:Intent=Intent(this,Login::class.java)
            startActivity(masuk)
        }
    }
}